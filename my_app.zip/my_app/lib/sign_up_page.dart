import 'package:flutter/material.dart';
import 'package:my_app/sign_in_page.dart';

void main() => runApp(signuppage());

class signuppage extends StatelessWidget {
  const signuppage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
       
        appBar: AppBar(),
        body: const MyCustomForm(),
      ),
    );
  }
}

class MyCustomForm extends StatelessWidget {
  const MyCustomForm({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
            Row(
              children: [
            const Text(
              'Get Started',
                style: TextStyle(
                        color: Color.fromARGB(255, 15, 100, 48),
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
            ),

            //enter your full name
            ],),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 16),
          child: TextField(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Full name',
              hintText: 'enter full name',
            ),
          ),
        ),



               // enter your email
         Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
          child: TextFormField(
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Email',
              hintText:  'enter email'
            ),
          ),
        ),

        
      //enter strong password

         Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
          child: TextFormField(
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'password',
              hintText:  'Enter password'
            ),
          ),
         ),

         SizedBox(height: 12,),

          Row(
              children: [
                Checkbox(value: true, onChanged: (val) {}),
                const Expanded(
                  child: Text(
                      "I agree to the processing of Personal Data"),
                )
              ],
             ),
                    //register here   so as to login

                           ElevatedButton(
                             onPressed: () {
                               Navigator.of(context).push(
                                 MaterialPageRoute(
                                   builder: (context) => const SignInPage(),
                                 ),
                               );
                             },
                             style: ElevatedButton.styleFrom(
                               backgroundColor: const Color.fromARGB(255, 1, 39, 23),
                               foregroundColor: const Color.fromARGB(255, 239, 243, 242),
                               padding: const EdgeInsets.symmetric(vertical: 16),
                               shape: RoundedRectangleBorder(
                                 borderRadius: BorderRadius.circular(8),
                               ),
                             ),
                             child: const Text('sign up'),
                           ),
                     
      
            const SizedBox(height: 20),
            const Text("Or sign up with"),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.facebook, color: Colors.blue),
                SizedBox(width: 20),
                Icon(Icons.g_mobiledata, color: Colors.red),
                SizedBox(width: 20),
                Icon(Icons.apple, color: Colors.black),
              ],
            ),





            TextButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/signin');
              },
              child: const Text("Already have an account? Sign In"),
            ),
      ],


      
    );
  }
}
